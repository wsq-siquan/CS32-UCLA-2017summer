#ifndef _U_C
#define _U_C




#include "Arena.cpp"


///////////////////////////////////////////////////////////////////////////
//  Auxiliary function implementations
///////////////////////////////////////////////////////////////////////////

int decodeDirection(char dir)
{
    switch (dir)
    {
      case 'u':  return UP;
      case 'd':  return DOWN;
      case 'l':  return LEFT;
      case 'r':  return RIGHT;
    }
    return -1;  // bad argument passed in!
}


///////////////////////////////////////////////////////////////////////////
//  clearScreen implementations
///////////////////////////////////////////////////////////////////////////

// Note to Xcode users:  clearScreen() will just write a newline instead
// of clearing the window if you launch your program from within Xcode.
// That's acceptable.

#ifdef _MSC_VER  //  Microsoft Visual C++

#include <windows.h>

void clearScreen()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(hConsole, &csbi);
    DWORD dwConSize = csbi.dwSize.X * csbi.dwSize.Y;
    COORD upperLeft = { 0, 0 };
    DWORD dwCharsWritten;
    FillConsoleOutputCharacter(hConsole, TCHAR(' '), dwConSize, upperLeft,
                                                        &dwCharsWritten);
    SetConsoleCursorPosition(hConsole, upperLeft);
}

#else  // not Microsoft Visual C++, so assume UNIX interface
#include <cstring>

void clearScreen()  // will just write a newline in an Xcode output window
{
    static const char* term = getenv("TERM");
    if (term == nullptr  ||  strcmp(term, "dumb") == 0)
        cout << endl;
    else
    {
        static const char* ESC_SEQ = "\x1B[";  // ANSI Terminal esc seq:  ESC [
        cout << ESC_SEQ << "2J" << ESC_SEQ << "H" << flush;
    }
}

#endif

#include <cassert>

#define CHECKTYPE(f, t) { (void)(t)(f); }

void thisFunctionWillNeverBeCalled()
{
    // If the student deleted or changed the interfaces to the public
    // functions, this won't compile.  (This uses magic beyond the scope
    // of CS 32.)
    
    Robot(static_cast<Arena*>(0), 1, 1);
    CHECKTYPE(&Robot::row,               int  (Robot::*)() const);
    CHECKTYPE(&Robot::col,               int  (Robot::*)() const);
    CHECKTYPE(&Robot::move,              void (Robot::*)());
    CHECKTYPE(&Robot::takeDamageAndLive, bool (Robot::*)());
    
    Player(static_cast<Arena*>(0), 1, 1);
    CHECKTYPE(&Player::row,                     int    (Player::*)() const);
    CHECKTYPE(&Player::col,                     int    (Player::*)() const);
    CHECKTYPE(&Player::age,                     int    (Player::*)() const);
    CHECKTYPE(&Player::isDead,                  bool   (Player::*)() const);
    CHECKTYPE(&Player::takeComputerChosenTurn,  string (Player::*)());
    CHECKTYPE(&Player::stand,                   void   (Player::*)());
    CHECKTYPE(&Player::move,                    void   (Player::*)(int));
    CHECKTYPE(&Player::shoot,                   bool   (Player::*)(int));
    CHECKTYPE(&Player::setDead,                 void   (Player::*)());
    
    Arena(1, 1);
    CHECKTYPE(&Arena::rows,          int     (Arena::*)() const);
    CHECKTYPE(&Arena::cols,          int     (Arena::*)() const);
    CHECKTYPE(&Arena::player,        Player* (Arena::*)() const);
    CHECKTYPE(&Arena::robotCount,    int     (Arena::*)() const);
    CHECKTYPE(&Arena::nRobotsAt,     int     (Arena::*)(int,int) const);
    CHECKTYPE(&Arena::display,       void    (Arena::*)(string) const);
    CHECKTYPE(&Arena::addRobot,      bool    (Arena::*)(int,int));
    CHECKTYPE(&Arena::addPlayer,     bool    (Arena::*)(int,int));
    CHECKTYPE(&Arena::damageRobotAt, void    (Arena::*)(int,int));
    CHECKTYPE(&Arena::moveRobots,    bool    (Arena::*)());
    
    Game(1,1,1);
    CHECKTYPE(&Game::play, void (Game::*)());
}

#endif // !_U_C