#ifndef _G_H
#define _G_H


#include "Arena.h"

//class Player;

class Game
{
  public:
        // Constructor/destructor
    Game(int rows, int cols, int nRobots);
    ~Game();

        // Mutators
    void play();

  private:
    Arena* m_arena;
};
#endif // !_G_H